<?php 
require 'classes/Database.php';

$database = new Database;